
public class building {

	int no_of_floors;

	public building(int no_of_floors) {
		super();
		this.no_of_floors = no_of_floors;
	}
	
}
